Andrés Montenegro
am@amsoftware.live
andresmontenegroarguello@gmail.com
https://amsoftware.co
https://andresmontenegro.co
*******
Examen 2

Todos los programas han sido desarrollados, compilados y probados en Mac OS X, pero la versión para Windows de cada programa ha sido incluida lista para ser compilada por el usuario en la plataforma nativa de Windows.